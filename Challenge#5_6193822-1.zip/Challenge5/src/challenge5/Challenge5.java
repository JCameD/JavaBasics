/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package challenge5;
import java.util.*;

/**
 *
 * 6193822
 */
public class Challenge5 {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) 
   {
       //Asks the user for a String and applies the recursive method
       String user = "yes";
       Scanner keyboard = new Scanner(System.in);
       do
       {
           String before;
           System.out.println("Enter any string with an x: ");
           before = keyboard.nextLine();
           System.out.println("Before Recursion: " + before);
           String after = changeXY(before);
           System.out.println("After Recursion: " + after);
           //Asks if the user would like to continue
           System.out.println("Would you like to do it again?");
           user = keyboard.nextLine();
           
       }while(user.equalsIgnoreCase("yes"));
   }

	public static String changeXY (String str) 
        {
            //Base Case:
            if (str.length()==0) 
            {    
                return str;
            }
    	    //Recursive Case:
            else if (str.charAt(0) == ('x'))
            {                    
            return 'y' + changeXY(str.substring(1));
            }
            else
            {
            return str.charAt(0) + changeXY(str.substring(1));
            }
	}

}
    

